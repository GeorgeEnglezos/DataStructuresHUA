package org.hua.project;

class code { //For saving the final codes
    int c;
    String code;

    public code(int c, String code) {
        this.c = c;
        this.code = code;
    }

    public int getC() {
        return c;
    }

    public String getCode() {
        return code;
    }

    public void setC(int c) {
        this.c = c;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
