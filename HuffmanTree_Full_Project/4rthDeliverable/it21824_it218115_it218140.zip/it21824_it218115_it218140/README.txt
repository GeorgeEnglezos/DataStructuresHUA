Με maven (εγκατάσταση Maven sudo apt install maven)
Ο φάκελος Project περιέχει όλο τον κώδικα.

1) mvn package
Μέσα στο root του φακέλου Project για να κάνω compile το Project.

2) java -cp target/Project-1.0-SNAPSHOT.jar org.hua.project.Main Files_To_Read/test_Input.txt output
Για την εκτέλεση του jar με ένα ενδεικτικό αρχείο. Τρέχουμε την εντολή στο root του φακέλου.
