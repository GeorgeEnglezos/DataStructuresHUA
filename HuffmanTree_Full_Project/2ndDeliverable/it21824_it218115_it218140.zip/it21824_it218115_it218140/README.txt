Με maven (εγκατάσταση Maven sudo apt install maven)
Ο φάκελος Project περιέχει τον κώδικα.

1)mvn package
Μέσα στο root του φακέλου Project για να κάνω compile το Project.

2)java -cp target/Project-1.0-SNAPSHOT.jar org.hua.project.Main
Για την εκτέλεση του jar τρέχουμε την εντολή στο ίδιο path.

3)cat frequencies.dat
Για να δω το αρχείο που φτιάχτηκε στο root του φακέλου.
