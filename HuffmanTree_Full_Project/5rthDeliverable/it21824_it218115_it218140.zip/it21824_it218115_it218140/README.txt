1) mvn package
Μέσα στο root του φακέλου Project για να κάνω compile το Project.

2) java -cp target/Project-1.0-SNAPSHOT.jar org.hua.project.Main Files_To_Read/test_Input.txt output
(Tέταρτο Παραδοτέο)Για την κωδικοποίηση ενδεικτικού αρχείου.

3) java -cp target/Project-1.0-SNAPSHOT.jar org.hua.project.Fifth output Decoded.txt
Για την αποκωδικοποίηση του αρχείου που φτιάχνει η προηγούμενη εντολή.

4) cat Decoded.txt
Για να δούμε το αποκωδικοποιημένο αρχείο.
