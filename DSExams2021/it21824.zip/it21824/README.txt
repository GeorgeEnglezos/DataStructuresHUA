1)mvn package
Μέσα στο root του φακέλου Project για να κάνω compile το Project.

2)java -cp target/Project-1.0-SNAPSHOT.jar org.hua.project.Main
Για την εκτέλεση του jar τρέχουμε την εντολή στο ίδιο path.
