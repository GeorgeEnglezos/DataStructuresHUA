
package org.hua.project;

/**
 * @author it21824
 */

public class Main
{

    public static void main(String[] args){
        Methods M = new Methods();
        //Εδώ γίνονται όλα
        M.loadAllFiles();

    }



}
